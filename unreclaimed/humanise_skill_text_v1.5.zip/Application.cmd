start compiler.exe dl.txt


